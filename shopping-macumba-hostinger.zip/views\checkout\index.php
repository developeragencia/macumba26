<?php ob_start(); ?>

<div class="bg-white rounded-lg shadow-lg p-8">
    <h1 class="text-3xl font-bold mb-6 text-macumba">💳 Finalizar Compra</h1>
    
    <p class="text-gray-600">Em desenvolvimento...</p>
</div>

<?php $content = ob_get_clean(); ?>
<?php include __DIR__ . '/../layout.php'; ?>

